#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 12:28:32 2023

@author: aafur
"""

print('Hello World')