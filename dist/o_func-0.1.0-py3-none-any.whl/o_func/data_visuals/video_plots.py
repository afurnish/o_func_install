# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 10:46:17 2023

@author: aafur
"""

class VideoPlots: