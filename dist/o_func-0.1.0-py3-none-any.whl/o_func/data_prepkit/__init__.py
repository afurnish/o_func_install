#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 10:41:37 2023

@author: aafur
"""
 
#### Not sure if this __init__ file is needed
from .open_nc import OpenNc
from .salinity_validation import extract_salinities
from .locations import primea_bounds_for_ukc4_slicing