# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 15:34:15 2023

@author: aafur
"""

