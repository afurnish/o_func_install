#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" This will be a omparison of several metrics which you will be able to pick to compare several model simultions. 

Created on Tue Sep 19 11:30:10 2023
@author: af
"""

