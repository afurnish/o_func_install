#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  8 16:12:16 2024

@author: af
"""

# Can run on UkC3 or PRIMEA model grid depending. 

if __name__ == '__main__':
    pass