# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 10:36:58 2023

@author: aafur
"""
# from iris.analysis.cartography import unrotate_pole
# class Transform:
#     def __init__(self, lon, lat):
#         self.lon = lon 
#         self.lat = lat
#         #uk defined centre of rotation
#         # lon, lat = 40, -42
#         lons, lats = unrotate_pole(rotated_lons, rotated_lats,  lon, lat)
        
#     #def unrotate_pols():
        
        
        
        