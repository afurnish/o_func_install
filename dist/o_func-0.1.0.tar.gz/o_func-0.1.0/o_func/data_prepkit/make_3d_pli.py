#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 11:11:44 2024

@author: af
"""

#take an input file. 

#