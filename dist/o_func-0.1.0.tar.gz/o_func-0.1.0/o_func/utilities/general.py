# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 15:56:52 2023

@author: aafur
"""

def gr(num):
    golden_ratio = num*((5**.5 + 1) / 2)
    return golden_ratio